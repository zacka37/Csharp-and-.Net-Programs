using System;

namespace MidtermProject{
    public enum Category{
        student,
        faculty,
        staff

    }
}