using System;

namespace MidtermProject{
    public enum StudentClass{
        freshman,
        sophomore,
        junior,
        senior
    }
    
}